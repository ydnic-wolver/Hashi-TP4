
load 'MainMenu.rb'

load 'Truc.rb'
window = MainMenu.new

Gtk.main
