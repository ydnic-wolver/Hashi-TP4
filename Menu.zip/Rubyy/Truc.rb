require 'gtk3'
load "APropos.rb"
load "Classement.rb"

class Truc < Gtk::Window
    def initialize
        super
        blue = Gdk::Color.parse("#CFFCFF")
		self.modify_bg(Gtk::StateType::NORMAL, blue)
		set_title "Hashi Game"
		set_resizable(true)
		signal_connect "destroy" do 
			Gtk.main_quit 
		end

		set_default_size 500, 400

		set_window_position Gtk::WindowPosition::CENTER


		show
    end
end
